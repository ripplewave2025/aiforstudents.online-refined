# ANTIGRAVITY BUILD SPECIFICATION
## AIforStudents.online - Complete Ecosystem
## Build Date: February 2026

---

## CRITICAL CONTEXT

You are building a complete education ecosystem for schools in Darjeeling, India, aligned with NEP 2020.

This is NOT a typical education platform. This system:
- Prioritizes curiosity over achievement
- Tracks learning vectors (direction + change), not scores
- Integrates school learning + vocational training + peer help
- Makes confusion safe and revision prestigious
- Helps students pass exams WITHOUT killing curiosity

**Core Philosophy:**
"Education is teaching humans to explore reality with curiosity, thinking, and tools - before certainty kills discovery."

**Pragmatic Addition:**
"Then giving them strategies to succeed in the current system."

---

## EXISTING CODEBASE

You previously built a Learning Vector Model platform with:
- Student/Teacher/Parent/Admin roles
- Question Log + AI Gate
- Thinking Trajectory (replaced CTI scores)
- Weekly Meaning Reflection
- Teacher Sensemaking Panels
- Parent growth narratives

**Location:** `/c/Users/FaradaysCage007/Desktop/2_PROJECTS/AIforStudents`

**Task:** Expand this codebase to include the complete ecosystem.

---

## BUILD SEQUENCE (6 Weeks, Sequential)

### WEEK 1: FOUNDATION + DATABASE
**Priority:** Get all tables deployed, test basic auth

**Tasks:**
1. Deploy complete schema from `aiforstudents-full-schema.sql`
2. Verify all 30 tables created
3. Test RLS policies
4. Add vocational_partner role to existing auth
5. Create seed data for testing
6. Verify existing features still work

**Deliverable:** Schema deployed, existing features functional

---

### WEEK 2: COMPLETE LEARNING VECTOR MODEL
**Priority:** Finish the core philosophical layer

**Tasks:**
1. Enhanced Question Refinement
   - Multi-step refinement tracking
   - Show "what changed" between versions
   - Initiated by: user | AI | peer | teacher

2. Thinking Sessions Completion
   - Evidence notes field
   - Counter-arguments field
   - Belief revision comparison (before/after)
   - Uncertainty expression toggle

3. Teacher Warm Message System
   - Weekly AI summary (internal view only)
   - Teacher message composition interface
   - Student receives teacher message (no AI visible)
   - Message history per student

4. Portfolio v1
   - Question evolution timeline
   - Belief revision log
   - Selected reflections
   - Visibility controls (private/school/public)

**Deliverable:** Core learning model is complete and testable

---

### WEEK 3: MEMORY TECHNIQUES + EXAM PREP
**Priority:** Add pragmatic exam success tools

**Tasks:**
1. Memory Technique Library
   - Database: memory_techniques table
   - CRUD interface (create, search, view, edit)
   - Fields: subject, topic, concept, understanding_first, memory_trick, trick_type
   - Practice questions array
   - Exam patterns notes
   - Community submission (students + teachers)
   - Upvote system
   - Verification by teachers
   - Bookmark functionality

2. Memory Technique UI Components
   ```jsx
   <MemoryTechniqueCard
     subject="Math"
     topic="Quadratic Formula"
     concept="x = (-b ± √(b²-4ac)) / 2a"
     understanding="Explanation..."
     memoryTrick="Negative Boy, Plus or Minus..."
     trickType="mnemonic"
     practiceQuestions={[...]}
     examPatterns="Often hidden in word problems"
     upvotes={47}
     onUpvote={handleUpvote}
     onBookmark={handleBookmark}
   />
   ```

3. Exam Preparation Mode
   - Exam entry form (subject, date, topics)
   - 4-week strategy generator
   - Daily task breakdown
   - Week 1: Understand weak topics
   - Week 2: Memory techniques + speed
   - Week 3: Practice papers + patterns
   - Week 4: Quick revision
   - Progress tracking per topic
   - Weak topic auto-detection
   - Integration with memory techniques

4. Exam Dashboard (Student)
   ```
   Active Exams:
   ├─ Math (March 15) - 3 weeks away
   ├─ Science (March 20) - 4 weeks away
   
   Today's Plan (Math):
   ├─ Topic: Algebra - Quadratic Equations
   ├─ Step 1: Understand [15 min]
   ├─ Step 2: Memory Trick [5 min]
   ├─ Step 3: Practice [20 min]
   └─ Progress: 2/3 complete
   ```

**Deliverable:** Students can prepare for exams strategically

---

### WEEK 4: PEER HELP NETWORK
**Priority:** Enable students to help each other, amplify teachers

**Tasks:**
1. Help Marketplace
   - Help request creation form
     - Subject, topic, question text
     - What tried, stuck on
     - Urgency (low/medium/high)
   - Help request listing (filterable)
   - Matching algorithm:
     - Find peers who explained this topic well before
     - Find available teachers
     - Suggest memory techniques
     - Suggest vocational connections
   - Response system (text + optional media)
   - Mark as resolved workflow
   - Helpfulness rating (1-5 stars)
   - "Pay it forward" prompt

2. Help Request Card UI
   ```jsx
   <HelpRequestCard
     student="Anonymous (or name if permitted)"
     subject="Science"
     topic="Photosynthesis"
     question="Why do plants need sunlight specifically?"
     whatTried={["Read textbook", "Watched video"]}
     urgency="medium"
     status="open"
     suggestedHelpers={[
       { type: 'peer', name: 'Anjali', rating: 4.8 },
       { type: 'teacher', name: 'Mr. Kumar', available: '4-5pm' }
     ]}
     onRespond={handleRespond}
   />
   ```

3. Teacher Availability System
   - Teacher sets availability
     - Days/times (recurring schedule)
     - Subject expertise
     - Max students per session
   - Student booking interface
   - Automatic matching suggestions
   - Calendar view
   - Notification system

4. Peer Study Groups
   - Group creation form
   - Subject/topic selection
   - Schedule picker
   - Max participants limit
   - Join/leave functionality
   - Group chat (simple)
   - Session notes

5. Reputation System (Lightweight)
   - Track: times helped, avg rating
   - Display: "Helped 7 students (4.9/5)"
   - No leaderboard, no gamification
   - Just quiet recognition

**Deliverable:** Students can get and give help

---

### WEEK 5: VOCATIONAL INTEGRATION
**Priority:** Connect schools with real-world skill providers

**Tasks:**
1. Vocational Institution Registration
   - Signup flow for vocational partners
   - Profile creation:
     - Name, category, description
     - Location, contact info
     - Skills offered (array)
     - How they integrate critical thinking
   - Verification pending state
   - Admin approval workflow

2. Vocational Program Management
   - Program creation form:
     - Name, category, skill focus
     - Which of the 10 basics this develops
     - Duration, sessions per week
     - Description, prerequisites
   - Program listing (public catalog)
   - Program detail view

3. School-Vocational Partnership System
   - School admin can browse vocational institutions
   - Send partnership request
   - Vocational institution accepts/declines
   - Active partnerships list
   - Programs offered through partnership
   - Student enrollment management

4. Student Vocational Enrollment
   - Browse vocational programs
   - Filter by: category, location, skill
   - Program detail view shows:
     - What you'll learn
     - How it builds critical thinking
     - Duration & schedule
     - Institution details
   - "Express Interest" button
   - School approval required
   - Enrollment confirmation
   - Track attendance & completion

5. Vocational Session Tracking
   - Vocational instructor can:
     - Record attendance
     - Add session notes
     - Link to student questions
     - Provide feedback
   - Student can:
     - Ask questions during vocational session
     - Questions appear in main question log
     - Reflect on vocational learning in weekly reflection

6. Cross-Context Linking
   - Questions tagged with context: 'school' | 'vocational' | 'peer_help' | 'self'
   - Weekly reflections can include all contexts
   - Portfolio shows growth across contexts

**Deliverable:** Schools can partner with vocational institutions and track student learning

---

### WEEK 6: UNIFICATION + POLISH
**Priority:** Make everything work together seamlessly

**Tasks:**
1. Unified Portfolio (Complete)
   ```
   Student Portfolio Structure:
   
   ├─ SCHOOL LEARNING
   │   ├─ Question Evolution Timeline
   │   ├─ Belief Revisions
   │   └─ Reflections (selected)
   │
   ├─ VOCATIONAL LEARNING
   │   ├─ Programs Completed
   │   ├─ Skills Developed
   │   └─ Projects
   │
   ├─ PEER TEACHING
   │   ├─ Help Given (count + rating)
   │   └─ Study Groups Led
   │
   ├─ CRITICAL THINKING GROWTH
   │   ├─ Question depth over time (chart)
   │   ├─ Hesitation trend (chart)
   │   ├─ Revision frequency (chart)
   │   └─ Exploration map
   │
   └─ SHARING CONTROLS
       ├─ Select artifacts to include
       ├─ Set visibility per artifact
       └─ Generate shareable link
   ```

2. Reality Signal Log (Internal Tool)
   - Admin-only interface
   - Log entry form:
     - Source, channel, raw quote
     - Observed emotion
     - Signal tag
   - Monthly review view
   - Pattern detection (manual)
   - Action tracking

3. Platform Metrics Dashboard (Admin)
   - School overview:
     - Active users, questions asked
     - Peer help activity
     - Vocational enrollments
     - Teacher engagement
   - Teacher activity tracking
   - NEP 2020 compliance metrics
   - Export reports (CSV/PDF)

4. Parent Comprehensive View
   ```
   Parent Dashboard:
   
   ├─ What They're Exploring
   │   ├─ Current interests
   │   ├─ Active vocational programs
   │   └─ Peer teaching activity
   │
   ├─ Signs of Growth
   │   ├─ Question quality improving
   │   ├─ Comfort with uncertainty
   │   └─ Revision moments
   │
   ├─ Teacher Messages
   │   └─ Warm messages from teachers
   │
   ├─ How to Support
   │   ├─ Age-specific guidance
   │   ├─ Questions to ask
   │   └─ Things to avoid
   │
   └─ Exam Progress (if active)
       ├─ Subjects preparing for
       ├─ Current focus
       └─ Progress status
   ```

5. UI/UX Polish
   - Consistent navigation across roles
   - Mobile-responsive everything
   - Loading states
   - Error handling
   - Empty states with helpful prompts
   - Onboarding tooltips
   - Keyboard shortcuts
   - Accessibility (ARIA labels, focus management)

6. Integration Testing
   - Complete user flows for all 5 roles
   - Cross-context workflows
   - Data consistency checks
   - Performance optimization
   - Security audit

**Deliverable:** Production-ready complete ecosystem

---

## USER ROLES & PERMISSIONS

### Student
**Can:**
- Create questions, reflections, thinking sessions
- View own trajectory and portfolio
- Submit memory techniques
- Request peer help
- Join study groups
- Browse and enroll in vocational programs
- Rate techniques and help received

**Cannot:**
- See other students' private data
- Access teacher/admin tools
- Approve vocational institutions

---

### Teacher
**Can:**
- View own school's students (anonymized or named based on privacy settings)
- See class-level patterns (not individual comparisons)
- Write warm messages to students
- Set availability for help sessions
- Respond to help requests
- Create and verify memory techniques
- Approve vocational enrollments (if assigned)
- Access sensemaking panels

**Cannot:**
- Assign scores or grades
- Access other schools' data
- Approve vocational institutions (admin only)

---

### Parent
**Can:**
- View own child's growth narratives
- See teacher messages
- Access guidance resources
- View vocational program details

**Cannot:**
- See raw questions/reflections unless child shares
- See other children's data
- Access detailed metrics
- Contact teachers directly through platform (use external channels)

---

### School Admin
**Can:**
- View school-wide analytics
- Manage teacher accounts
- Browse and partner with vocational institutions
- Generate NEP compliance reports
- View reality signal log
- Approve student vocational enrollments

**Cannot:**
- See individual student detailed data
- Modify student/teacher content directly

---

### Vocational Partner
**Can:**
- Create and manage programs
- View enrolled students (limited info)
- Track attendance and sessions
- Provide feedback
- See questions from their sessions

**Cannot:**
- Access school academic data
- See students from non-partner schools
- Modify platform settings

---

## KEY UI COMPONENTS TO BUILD

### 1. Question Log Interface (Enhanced)
```jsx
<QuestionLog
  questions={questions}
  onAskQuestion={handleAskQuestion}
  onRefineQuestion={handleRefine}
  showAIGate={!aiUnlocked}
  context="school" // or 'vocational', 'peer_help', 'self'
/>

<QuestionCard
  question={question}
  refinements={refinements}
  initialBelief={initialBelief}
  assumptions={assumptions} // optional
  uncertaintyExpressed={boolean}
  aiGateStatus="locked" | "unlocked"
  onRefine={handleRefine}
  onUnlockAI={handleUnlock}
  showEvolution={true} // show how question changed
/>
```

### 2. Memory Technique Components
```jsx
<MemoryTechniqueLibrary
  onSearch={handleSearch}
  onSubmit={handleSubmit}
  onRate={handleRate}
  userBookmarks={bookmarks}
/>

<MemoryTechniqueSubmitForm
  onSubmit={handleSubmit}
  subjects={subjects}
  requiredFields={['concept', 'understanding', 'trick']}
/>

<MemoryTechniqueCard
  technique={technique}
  onUpvote={handleUpvote}
  onBookmark={handleBookmark}
  onRate={handleRate}
  showPractice={true}
/>
```

### 3. Help Marketplace Components
```jsx
<HelpRequestForm
  onSubmit={handleSubmit}
  subjectOptions={subjects}
/>

<HelpRequestFeed
  requests={openRequests}
  filterBy={filterOptions}
  onRespond={handleRespond}
/>

<HelpMatchingPanel
  request={request}
  suggestedPeers={peers}
  suggestedTeachers={teachers}
  memoryTechniques={techniques}
  vocationalLinks={links}
  onSelectHelper={handleSelect}
/>

<HelpResponseThread
  request={request}
  responses={responses}
  onReply={handleReply}
  onResolve={handleResolve}
  onRate={handleRate}
/>
```

### 4. Exam Preparation Components
```jsx
<ExamPrepDashboard
  activeExams={exams}
  onAddExam={handleAddExam}
/>

<ExamStrategyBuilder
  exam={exam}
  onGeneratePlan={handleGenerate}
  weeklyPlan={plan}
  onUpdateProgress={handleProgress}
/>

<DailyStudyPlan
  tasks={todaysTasks}
  onComplete={handleComplete}
  memoryTechniques={linkedTechniques}
/>

<WeakTopicDetector
  examData={examData}
  studentHistory={history}
  suggestedFocus={topics}
  onSelectTopic={handleSelect}
/>
```

### 5. Vocational Integration Components
```jsx
<VocationalProgramCatalog
  programs={programs}
  onFilter={handleFilter}
  onEnroll={handleEnroll}
/>

<VocationalProgramCard
  program={program}
  institution={institution}
  criticalThinkingElements={elements}
  onExpressInterest={handleInterest}
/>

<VocationalSessionTracker
  enrollment={enrollment}
  sessions={sessions}
  onRecordAttendance={handleAttendance}
  onLinkQuestion={handleLinkQuestion}
/>

<SchoolPartnershipManager
  school={school}
  vocationalPartners={partners}
  pendingRequests={requests}
  onApprove={handleApprove}
/>
```

### 6. Portfolio Components
```jsx
<UnifiedPortfolio
  student={student}
  schoolArtifacts={schoolArtifacts}
  vocationalArtifacts={vocationalArtifacts}
  peerTeachingArtifacts={peerArtifacts}
  growthCharts={charts}
  onUpdateVisibility={handleVisibility}
  onSelectArtifacts={handleSelect}
  onGenerateShareLink={handleShare}
/>

<PortfolioArtifact
  type="question_evolution" | "belief_revision" | "vocational_project" | "peer_teaching"
  content={content}
  context="school" | "vocational" | "peer_help"
  reflection={reflection}
  visibility="private" | "school" | "public"
  onEditReflection={handleEdit}
  onChangeVisibility={handleVisibility}
/>
```

### 7. Teacher Tools Components
```jsx
<ClassSensemakingPanel
  classData={classData}
  silenceZones={silenceZones}
  confusionClusters={confusionClusters}
  revisionMoments={revisionMoments}
  weeklyThemes={themes}
/>

<WarmMessageComposer
  student={student}
  aiSummary={aiSummary} // internal only, not shown to student
  onSendMessage={handleSend}
  previousMessages={messageHistory}
/>

<TeacherAvailabilityScheduler
  teacher={teacher}
  availability={availability}
  bookings={bookings}
  onUpdateSchedule={handleUpdate}
/>
```

---

## CRITICAL IMPLEMENTATION RULES

### 1. NO SCORES OR RANKINGS
```jsx
// ❌ NEVER DO THIS
<StudentRank rank={3} total={30} />
<CTIScore score={72} />
<Leaderboard students={students} />

// ✅ ALWAYS DO THIS
<ThinkingTrajectory
  questionDepth={depthOverTime}
  hesitationTrend={hesitationTrend}
  revisionFrequency={revisionFrequency}
/>
```

### 2. AI NEVER REPLACES HUMAN INTERPRETATION
```jsx
// ❌ NEVER DO THIS
<AIFeedback
  message="You're doing great! Keep it up!"
  from="AI Assistant"
/>

// ✅ ALWAYS DO THIS
<TeacherMessage
  message="I noticed you changed your mind about gravity..."
  from="Ms. Sharma"
  aiSummaryVisibleTo="teacher_only"
/>
```

### 3. PRIVACY BY DEFAULT
```jsx
// ✅ DEFAULT STATE
const artifact = {
  visibility: 'private', // default
  shareableLink: null,
  sharedWith: []
};

// Student must explicitly choose to share
<VisibilityControls
  current="private"
  options={['private', 'school', 'public']}
  onChange={handleChange}
  warning="Changing to public will make this visible to anyone with the link"
/>
```

### 4. UNCERTAINTY IS ENCOURAGED
```jsx
// ✅ ENCOURAGE UNCERTAINTY
<UncertaintyToggle
  value={uncertaintyExpressed}
  onChange={handleToggle}
  helpText="It's perfectly fine to be unsure! That's where learning begins."
/>

// ❌ NEVER PRESSURE CERTAINTY
// No "Are you sure?" without context
// No red warnings for uncertainty
// No penalties for "I don't know"
```

### 5. MEMORY TECHNIQUES COME AFTER UNDERSTANDING
```jsx
// ✅ CORRECT ORDER
<MemoryTechniqueFlow>
  <Step1_Understanding required>
    Explain why/how this works
  </Step1_Understanding>
  <Step2_MemoryTrick enabled={understandingComplete}>
    Now here's a trick to remember it
  </Step2_MemoryTrick>
  <Step3_Practice>
    Apply both understanding and memory
  </Step3_Practice>
</MemoryTechniqueFlow>
```

---

## DATA FLOW EXAMPLES

### Example 1: Student Asks Question in Vocational Session
```
1. Student in culinary class wonders: "Why does yeast need warm water?"
2. Student opens platform → Ask Question
3. Context auto-detected: 'vocational' (if from vocational institution account)
   OR manually selected: 'vocational'
4. Question saved with context_id = culinary_session_id
5. AI Gate locks (must think first)
6. Student writes initial belief, optionally assumptions
7. AI Gate unlocks
8. Student explores with AI
9. Question appears in:
   - Student's main question log
   - Vocational instructor's session view
   - Teacher's class patterns (if relevant to science)
10. Weekly reflection might reference this question
11. Portfolio can include this as cross-context learning
```

### Example 2: Peer Help Request → Resolution
```
1. Student A stuck on fractions
2. Posts help request
3. Platform matches:
   - Student B (explained fractions to 5 students, 4.8/5 rating)
   - Teacher C (available 4-5pm today)
   - Memory technique: "Fraction Addition RULE"
4. Student B responds with explanation
5. Student A asks follow-up question
6. Student B responds again
7. Student A marks as resolved
8. Rates Student B: 5 stars
9. Platform updates Student B's reputation
10. Platform suggests Student A can now help others with fractions
11. This interaction appears in both portfolios
```

### Example 3: Exam Preparation → Success
```
1. Student enters: Math exam, March 15, weak on algebra
2. System generates 4-week plan
3. Week 1, Day 1: "Understand: Why do we use variables?"
4. Student explores with AI, asks questions
5. Week 1, Day 3: "Memory trick: PEMDAS for order of operations"
6. Student practices with memory technique
7. Week 2: Timed practice problems
8. Student identifies still weak on quadratic equations
9. System adjusts plan, adds focus
10. Student requests peer help for quadratics
11. Peer explains, student understands
12. Week 3: Practice papers
13. Week 4: Quick revision using bookmarked memory techniques
14. Exam day: Student performs well
15. Reflection: "Memory tricks helped, but understanding first was key"
```

---

## TESTING CHECKLIST

After each week's build, test these flows:

### Week 1 Checklist
- [ ] User can create account (all 5 roles)
- [ ] Student can log in and see dashboard
- [ ] Teacher can log in and see class view
- [ ] Schema tables all populated correctly
- [ ] RLS policies prevent unauthorized access

### Week 2 Checklist
- [ ] Student can ask question and refine it
- [ ] AI Gate locks until thinking submitted
- [ ] Belief revision tracked correctly
- [ ] Teacher can see patterns (silence, confusion)
- [ ] Teacher can write warm message
- [ ] Student receives message (no AI visible)

### Week 3 Checklist
- [ ] Student can search memory techniques
- [ ] Student can submit technique
- [ ] Teacher can verify technique
- [ ] Student can create exam prep plan
- [ ] Daily study tasks generate correctly
- [ ] Weak topics detected from history

### Week 4 Checklist
- [ ] Student can post help request
- [ ] Platform suggests helpers correctly
- [ ] Peer can respond to help request
- [ ] Teacher can set availability
- [ ] Student can book teacher session
- [ ] Study group can be created and joined

### Week 5 Checklist
- [ ] Vocational institution can register
- [ ] Admin can approve institution
- [ ] Vocational partner can create programs
- [ ] School can browse and partner
- [ ] Student can enroll in program
- [ ] Session tracking works correctly
- [ ] Questions link to vocational context

### Week 6 Checklist
- [ ] Portfolio shows all contexts
- [ ] Reality signal log captures feedback
- [ ] Platform metrics calculate correctly
- [ ] Parent view shows comprehensive growth
- [ ] NEP reports generate correctly
- [ ] Entire system works end-to-end

---

## DEPLOYMENT STRATEGY

### Environment Setup
```
Development: Local + Supabase dev project
Staging: Vercel preview + Supabase staging
Production: Vercel prod + Supabase prod
```

### Week-by-Week Deployment
- Week 1-2: Dev only
- Week 3: Deploy to staging, internal testing
- Week 4: Continue staging, teacher preview
- Week 5: Deploy to production (Beta), invite 1 school
- Week 6: Full production, ready for scaling

### Data Migration
If migrating from existing platform:
1. Export questions, reflections, users
2. Transform to new schema
3. Import with preserved timestamps
4. Verify data integrity
5. Archive old system

---

## SUCCESS CRITERIA

After 6 weeks, the platform must:

✅ Allow students to explore AND prepare for exams  
✅ Enable peer-to-peer learning at scale  
✅ Connect schools with vocational partners  
✅ Track learning vectors across contexts  
✅ Preserve teacher humanity (no score burden)  
✅ Build trust with parents  
✅ Generate NEP 2020 compliance reports  
✅ Handle 100+ concurrent users without performance issues  
✅ Work on mobile (responsive design)  
✅ Maintain philosophy (no scores, no surveillance)  

If any of these fail, system is not ready.

---

## FINAL NOTES FOR ANTIGRAVITY

1. **Preserve existing work** - Don't break what's already built
2. **Sequential deployment** - Each week must be functional before moving to next
3. **Test at checkpoints** - Verify features work before adding more
4. **Keep philosophy intact** - If a feature adds scores/rankings, reject it
5. **Mobile-first** - Every interface must work on phone
6. **Performance matters** - Large datasets must load quickly
7. **Accessibility required** - WCAG 2.1 AA compliance
8. **Security non-negotiable** - RLS policies must be bulletproof

This is a 6-week aggressive build, but it's achievable if done sequentially with discipline.

Let's build something that changes education.
